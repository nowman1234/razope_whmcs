<?php	

include("../../../init.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");
require_once(__DIR__ . '/../scanpay/check.php');

$url = $_SERVER["SERVER_NAME"];

$gatewayModuleName = basename(__FILE__, '.php');


$gatewayParams = getGatewayVariables($gatewayModuleName);


if (!$gatewayParams['type']) {
    die("Module Not Activated");
}


$secretKey = $gatewayParams['secret'];


$verifysighskakajakakakka = '';
$array = array();
$paramList = array();

$secret = $secretKey; 
$status = $_POST['status']; 
$message = $_POST['message']; 
$cust_Mobile = $_POST['cust_Mobile']; 
$cust_Email = $_POST['cust_Email']; 
$hash = $_POST['hash']; 
$alowowlqhehs = $_POST['checksum'];  
$transactionStatus = $status ? 'SUCCESS' : 'Failure';
if ($status == "SUCCESS") {
    $paramList = hash_decrypt($hash, $secret);
    $verifysighskakajakakakka = NeroSecrettevetfahe::verifySignature($paramList, $secret, $alowowlqhehs);

    
    if ($verifysighskakajakakakka) {
        $array = json_decode($paramList);

        
        $paymentStatus = $status;
        $paymentMessage = $message;
        $paymentHash = $hash;
        $paymentChecksum = $alowowlqhehs;
        $customerMobile = $cust_Mobile;      
        $customerEmail = $cust_Email;        
        $senderNote = $array->sender_note;   
        $amount = $array->txnAmount;         
        $orderId = $array->orderId;          
        $txnStatus = $array->txnStatus;      
        $resultInfo = $array->resultInfo;    
        $txnId = $array->txnId;              
        $bankTxnId = $array->bankTxnId;      
        $paymentMode = $array->paymentMode;  
        $txnDate = $array->txnDate;          
        $utr = $array->utr;                  
        $senderVpa = $array->sender_vpa;     
        $payeeVpa = $array->payee_vpa;       
 }
else {
        header("Location: https://$url/");
exit;
    }
} else {
    header("Location: https://$url/");
exit;
}



$invoiceId = $senderNote;
$transactionId = $orderId;
$paymentAmount = $amount;


$invoiceId = checkCbInvoiceID($invoiceId, $gatewayParams['name']);


checkCbTransID($transactionId);


logTransaction($gatewayParams['name'], $_POST, $transactionStatus);

$paymentSuccess = false;

 if($status) {


    addInvoicePayment(
        $invoiceId,
        $transactionId,
        $paymentAmount,
        "0.0",
        $gatewayModuleName
    );

    $paymentSuccess = true;

}


callback3DSecureRedirect($invoiceId, $paymentSuccess);

?>