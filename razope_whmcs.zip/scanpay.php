<?php

require_once(dirname(__FILE__) . '/scanpay/check.php');

function scanpay_config()
{
    $configarray = array(
        "FriendlyName" => array("Type" => "System", "Value" => "Razope"),
        "token" => array("FriendlyName" => "Token", "Type" => "text", "Size" => "120"),
        "secret" => array("FriendlyName" => "Secret Key", "Type" => "text", "Size" => "50"),
        "upiid" => array("FriendlyName" => "Upi ID", "Type" => "text", "Size" => "150"),
    );
    return $configarray;
}

function scanpay_link($params)
{

    
    $invoiceId = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];

    
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];
    

    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    $icid = $params['invoiceid'] . '_' . time();
    $amount = $params['amount'];
    setcookie("my_cookie", $icid, time() + 300, "/");
    setcookie("my_amount", $amount, time() + 300, "/");
    $token = $params['token'];
    $secret = $params['secret'];
    $RECHPAY_ENVIRONMENT = 'PROD';

    $alowowlqhehs = "";
    $upiuid = "";
    $paramList = array();

    $cust_Mobile = '7985728171';
    $cust_Email = $email;

    $txnAmount = $amount;
    $txnNote = $invoiceId;


    $callback = $systemUrl . '/modules/gateways/callback/' . $moduleName . '.php';

    $TXN_URL = 'https://razope.com/order/process';

    $upiuid = $params['upiid'];

    $paramList["cust_Mobile"] = $cust_Mobile;
    $paramList["cust_Email"] = $cust_Email;

    $paramList["upiuid"] = $upiuid;
    $paramList["token"] = $token;
    $paramList["orderId"] = $icid;
    $paramList["txnAmount"] = $txnAmount;
    $paramList["txnNote"] = $txnNote;
    $paramList["callback_url"] = $callback;

    $alowowlqhehs = ScanpaySecrettevetfahe::generateSignature($paramList, $secret);

    $code = '<form method="post" action="' . $TXN_URL . '" name="f1">
        <table border="1">
            <tbody>';
    foreach ($paramList as $name => $value) {
        $code .= '<input type="hidden" name="' . $name . '" value="' . $value . '">';
    }
    $code .= '<input type="hidden" name="checksum" value="' . $alowowlqhehs . '">
            </tbody>
        </table>
        <input type="submit" value="Pay Now">
    </form>';

    return $code;
}

function scanpay_cancelSubscription($params)
{

    $accountId = $params['accountID'];
    $secret = $params['secret'];
    $testMode = $params['testMode'];
    $dropdownField = $params['dropdownField'];
    $radioField = $params['radioField'];
    $textareaField = $params['textareaField'];

    
    $subscriptionIdToCancel = $params['subscriptionID'];

    
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    return array(
        
        'status' => 'success',
        
        'rawdata' => $responseData,
    );
}
?>
